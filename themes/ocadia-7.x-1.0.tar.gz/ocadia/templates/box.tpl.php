<div class="post">
  <h2><?php print $title; ?></h2>  
  <div class="content">
    <?php print $content; ?>
  </div>
</div>
