<?php if (!empty($block->subject)): ?>
  <h2 class="block-title"><?php print $block->subject; ?></h2>
<?php endif; ?>
<div class="block-bar">
  <?php print $content; ?>
</div>
